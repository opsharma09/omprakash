<?php 
class Users extends CI_Controller
{
    function __construct() {
        parent::__construct();
        $this->load->model('Common');
        $this->load->helper('cookie');
        $this->load->library('form_validation');
        $this->load->helper('form');
        $this->load->helper('url');

        
    }
	public function index($param='',$param2=''){
        $session_data=$this->session->userdata('user');
        if($session_data->user_type != 3)
        {
                redirect(base_url().'login');exit;
        }
        $data['all_data']=$this->Common->select_data('users','*',array('user_type' => 1));
        $data['page_title']="Users";
        $this->load->view('admin/includes/header',$data);
        $this->load->view('admin/users',$data);
        $this->load->view('admin/includes/footer');
        
    }
    public function add(){
        $session_data=$this->session->userdata('user');
        if($session_data->user_type != 3)
        {
                redirect(base_url().'login');exit;
        }
        if($this->input->method()=='post'){
            $this->form_validation->set_rules('first_name','First Name','required');
            $this->form_validation->set_rules('last_name','Last Name','required');
            $this->form_validation->set_rules('phone_no','phone_no','required');
            $this->form_validation->set_rules('email_id','email_id','required');
        
            if($this->form_validation->run()=='true'){
                $data = array (
                        'first_name'=>$_POST['first_name'],
                        'last_name'=>$_POST['last_name'],
                        'phone_no'=>'+91'.$_POST['phone_no'],
                        'email_id'=>$_POST['email_id'],
                        'address'=>$_POST['address'],
                        'status'=>$_POST['status'],
                        'password'=>password_hash($_POST['password'], PASSWORD_BCRYPT),
                        );
                $resp=$this->Common->insert_data('users',$data);
                $insert_id = $this->db->insert_id();
                redirect(base_url('users'));
            }else{
                print_r(validation_errors());
            }
        }else{
            $data['page_title']="Add Users";
            $this->load->view('admin/includes/header',$data);
            $this->load->view('admin/add_users',$data);
            $this->load->view('admin/includes/footer');
        } 
    }
    public function edit($param=''){
        $session_data=$this->session->userdata('user');
        if($session_data->user_type != 3)
        {
                redirect(base_url().'login');exit;
        }
        if($param != ''){
            if($this->input->method()=='post'){
                $this->form_validation->set_rules('first_name','First Name','required');
                $this->form_validation->set_rules('last_name','Last Name','required');
                $this->form_validation->set_rules('phone_no','phone_no','required');
                $this->form_validation->set_rules('email_id','email_id','required');
            
                if($this->form_validation->run()=='true'){
                    $data = array (
                            'first_name'=>$_POST['first_name'],
                            'last_name'=>$_POST['last_name'],

                            'phone_no'=>$_POST['phone_no'],
                            'email_id'=>$_POST['email_id'],
                            'address'=>$_POST['address'],
                            'status'=>$_POST['status'],
                            'password'=>password_hash($_POST['password'], PASSWORD_BCRYPT),
                            );
                    $resp=$this->Common->update('users',$data,array('user_id'=>$param));
                    redirect(base_url('users'));
                }else{
                    print_r(validation_errors());
                }
            }else{

                $data['user_info']=$this->db->query("SELECT * FROM users where user_id = $param")->row();
                $data['page_title']="Edit Users";
                $this->load->view('admin/includes/header',$data);
                $this->load->view('admin/edit_users',$data);
                $this->load->view('admin/includes/footer');
            } 
        }
    }
    

}
?>